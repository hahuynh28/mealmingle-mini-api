package com.mealmingle.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealmingleMiniApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealmingleMiniApiApplication.class, args);
	}

}
